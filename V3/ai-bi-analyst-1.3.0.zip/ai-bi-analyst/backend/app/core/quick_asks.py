"""ENH-04 — Quick Ask suggestions generated from the dataset, not hardcoded.

Each suggestion carries a stable id and a structured intent. The backend maps
the intent to a governed analysis plan (or, for driver questions, to the
association engine), so nothing depends on parsing the visible label text. A
suggestion is only emitted when the columns it needs exist and have the right
analytical role, which is what stops "associated with churn" appearing on a
dataset that has no churn column.
"""

from __future__ import annotations

import hashlib
import time
from typing import Literal

from ..schemas import (
    Aggregation,
    AnalysisPlan,
    AnalyticalRole,
    MetricSpec,
    PlanResult,
    QuickAsk,
    QuickAskIntent,
)
from .relationships import analyse_pair
from .semantics import ColumnSemantics

NUMERIC_ROLES = {AnalyticalRole.measure, AnalyticalRole.currency, AnalyticalRole.percentage}
CATEGORY_ROLES = {AnalyticalRole.categorical_dimension, AnalyticalRole.geography}

QuickAskCategory = Literal["kpi", "comparison", "trend", "ranking", "distribution", "relationship"]


def _stable_id(kind: str, columns: list[str]) -> str:
    digest = hashlib.sha256("|".join([kind, *sorted(columns)]).encode("utf-8")).hexdigest()
    return f"qa-{kind}-{digest[:8]}"


def _rank_measures(semantics: list[ColumnSemantics]) -> list[ColumnSemantics]:
    from ..llm.service import rank_measures

    return rank_measures(semantics)


def _rank_dimensions(semantics: list[ColumnSemantics]) -> list[ColumnSemantics]:
    from ..llm.service import rank_dimensions

    return rank_dimensions(semantics)


def generate_quick_asks(semantics: list[ColumnSemantics], row_count: int) -> list[QuickAsk]:
    """Build the shortlist. Order is deterministic, so ids are stable per dataset."""
    measures = _rank_measures(semantics)
    dims = _rank_dimensions(semantics)
    dates = [s for s in semantics if s.analytical_role == AnalyticalRole.datetime_dimension]
    rankable = [s for s in semantics if s.analytical_role in CATEGORY_ROLES and 3 <= s.distinct_count <= 500]

    out: list[QuickAsk] = []

    def add(
        kind: str,
        category: QuickAskCategory,
        label: str,
        question: str,
        intent: QuickAskIntent,
        columns: list[str],
    ) -> None:
        out.append(
            QuickAsk(
                id=_stable_id(kind, columns),
                label=label,
                question=question,
                category=category,
                intent=intent,
                required_columns=columns,
            )
        )

    if measures:
        top = measures[:3]
        add(
            "kpi_overview",
            "kpi",
            "Headline KPIs",
            "What are the best executive KPIs for this dataset?",
            QuickAskIntent(
                kind="kpi_overview",
                metrics=[_metric(m) for m in top],
                limit=1,
            ),
            [m.name for m in top],
        )

    if measures and dims:
        measure, dimension = measures[0], dims[0]
        add(
            "measure_by_dimension",
            "comparison",
            f"{measure.label} by {dimension.label}",
            f"What is total {measure.label} by {dimension.label}?",
            QuickAskIntent(
                kind="measure_by_dimension",
                metrics=[_metric(measure)],
                dimensions=[dimension.name],
                limit=25,
            ),
            [measure.name, dimension.name],
        )

    if measures and dates:
        measure, date = measures[0], dates[0]
        grain = _grain_for(date, row_count)
        add(
            "trend",
            "trend",
            f"{measure.label} over time",
            f"How has {measure.label} moved over time?",
            QuickAskIntent(
                kind="trend",
                metrics=[_metric(measure)],
                time_dimension=date.name,
                time_grain=grain,
                limit=200,
            ),
            [measure.name, date.name],
        )

    if measures and rankable:
        measure, dimension = measures[0], rankable[0]
        add(
            "top_n",
            "ranking",
            f"Top 10 {dimension.label}",
            f"Top 10 {dimension.label} by {measure.label}",
            QuickAskIntent(
                kind="top_n",
                metrics=[_metric(measure)],
                dimensions=[dimension.name],
                limit=10,
            ),
            [measure.name, dimension.name],
        )

    if len(measures) >= 2 and dims:
        first, second, dimension = measures[0], measures[1], dims[0]
        add(
            "compare_measures",
            "comparison",
            f"{first.label} vs {second.label}",
            f"Compare {first.label} and {second.label} by {dimension.label}",
            QuickAskIntent(
                kind="compare_measures",
                metrics=[_metric(first), _metric(second)],
                dimensions=[dimension.name],
                limit=25,
            ),
            [first.name, second.name, dimension.name],
        )

    if measures:
        measure = measures[0]
        add(
            "distribution",
            "distribution",
            f"Spread of {measure.label}",
            f"How is {measure.label} distributed?",
            QuickAskIntent(
                kind="distribution",
                metrics=[
                    MetricSpec(column=measure.name, aggregation=Aggregation.min, label=f"Minimum {measure.label}"),
                    MetricSpec(column=measure.name, aggregation=Aggregation.median, label=f"Median {measure.label}"),
                    MetricSpec(column=measure.name, aggregation=Aggregation.avg, label=f"Average {measure.label}"),
                    MetricSpec(column=measure.name, aggregation=Aggregation.max, label=f"Maximum {measure.label}"),
                ],
                limit=1,
            ),
            [measure.name],
        )

    # A driver question is only offered when there is something to correlate
    # against, and it names the real target column rather than a generic noun.
    target = _driver_target(semantics, measures)
    if target is not None and len(semantics) >= 3:
        add(
            "drivers",
            "relationship",
            f"What moves {target.label}?",
            f"Which factors appear most associated with {target.label}?",
            QuickAskIntent(kind="drivers", target_column=target.name, limit=8),
            [target.name],
        )

    return out


def _metric(column: ColumnSemantics) -> MetricSpec:
    aggregation = (
        column.default_aggregation if column.default_aggregation not in (Aggregation.none,) else Aggregation.sum
    )
    prefix = {
        Aggregation.sum: "Total",
        Aggregation.avg: "Average",
        Aggregation.median: "Median",
        Aggregation.count_distinct: "Distinct",
    }.get(aggregation, aggregation.value.title())
    return MetricSpec(column=column.name, aggregation=aggregation, label=f"{prefix} {column.label}")


def _grain_for(date: ColumnSemantics, row_count: int) -> str:
    if date.parsed_datetime is None:
        return "month"
    values = date.parsed_datetime.dropna()
    if values.empty:
        return "month"
    days = (values.max() - values.min()).days
    if days <= 120:
        return "day"
    if days <= 400:
        return "week"
    if days <= 2000:
        return "month"
    return "quarter"


def _driver_target(semantics: list[ColumnSemantics], measures: list[ColumnSemantics]) -> ColumnSemantics | None:
    """Prefer an obvious outcome flag, else the headline measure."""
    for column in semantics:
        name = column.name.lower()
        outcome_word = any(
            word in name for word in ("churn", "attrition", "default", "fraud", "conversion", "retained")
        )
        usable = column.analytical_role in CATEGORY_ROLES | NUMERIC_ROLES and column.distinct_count >= 2
        if outcome_word and usable:
            return column
    return measures[0] if measures else None


def plan_for_intent(intent: QuickAskIntent, question: str) -> AnalysisPlan:
    """Deterministic intent to plan mapping. No text parsing, no model."""
    return AnalysisPlan(
        intent=question[:200],
        metrics=list(intent.metrics),
        dimensions=list(intent.dimensions),
        time_dimension=intent.time_dimension,
        time_grain=intent.time_grain,  # type: ignore[arg-type]
        sort_desc=True,
        limit=intent.limit,
        assumptions=[f"Quick Ask '{intent.kind}' used the dataset's inferred roles and default aggregations."],
    )


def driver_result(df, semantics: list[ColumnSemantics], target: str, limit: int = 8) -> PlanResult:
    """Rank association strength against a target column, using the engine.

    This is not SQL, and the result says so, because presenting association
    output as if it were an aggregate query would be misleading.
    """
    started = time.perf_counter()
    by_name = {s.name: s for s in semantics}
    if target not in by_name:
        raise KeyError(target)
    anchor = by_name[target]

    rows: list[dict] = []
    for candidate in semantics:
        if candidate.name == target:
            continue
        if candidate.analytical_role in (
            AnalyticalRole.identifier,
            AnalyticalRole.free_text,
            AnalyticalRole.sensitive,
            AnalyticalRole.unusable,
        ):
            continue
        result = analyse_pair(df, anchor, candidate)
        if not result.reliable or result.statistic is None:
            continue
        rows.append(
            {
                "Factor": candidate.label,
                "Method": result.method.replace("_", " "),
                "Association": round(abs(result.statistic), 4),
                "Direction": ("positive" if result.statistic > 0 else "negative" if result.statistic < 0 else "flat")
                if result.method in ("pearson", "spearman_vs_time", "point_biserial")
                else "n/a",
                "Effect": result.effect_size_label or "unclear",
                "Sample": result.sample_size,
            }
        )

    rows.sort(key=lambda row: row["Association"], reverse=True)
    truncated = len(rows) > limit
    rows = rows[:limit]
    plan = AnalysisPlan(
        intent=f"Association strength against {anchor.label}",
        metrics=[],
        dimensions=[],
        limit=limit,
        assumptions=[
            "Association only. A ranked factor is a place to look, not a proven cause.",
            "Each pair uses the statistic appropriate to its two analytical roles.",
        ],
    )
    return PlanResult(
        plan=plan,
        columns=["Factor", "Method", "Association", "Direction", "Effect", "Sample"],
        rows=rows,
        row_count=len(rows),
        truncated=truncated,
        executed_ms=int((time.perf_counter() - started) * 1000),
        sql_like=(
            f'-- computed by the relationship engine against "{target}"\n'
            "-- type-aware statistic per pair; no SQL aggregate was executed"
        ),
    )
